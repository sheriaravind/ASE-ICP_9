/**
 * Created by mnpw3d on 20/10/2016.
 */
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var url = 'mongodb://root:root@ds137261.mlab.com:37261/aseprojectsheriaravind';
//var url = 'mongodb://marmik:2621@ds051923.mlab.com:51923/demo';
var insertDocument = function(db, callback) {
    var dbo = db.db("aseprojectsheriaravind");
    dbo.collection('demoase').insertOne( {
        "fname" : "Aravind",
        "lname" : "Sheri",
        "userid" : "001",
        "ph.no" : "9998887771",
        "address":{
            "street":"charlotte st",
            "city":"Kansas City",
            "state":"MO"
        },
        "education" : {
            "university":"UMKC",
            "degree":"Master of Science",
            "major":"Computer Science"
        },
        "mail":"aravind.kks10@gmail.com"
    }, function(err, result) {
        assert.equal(err, null);
        console.log("Inserted a document into the asedemo collection.");
        callback();
    });
};
MongoClient.connect(url, function(err, db) {
    assert.equal(null, err);
    insertDocument(db, function() {
        db.close();
    });
});